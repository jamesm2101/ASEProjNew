﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASEProjNew
{
    public enum Action
    {

        moveTo,drawTo,Clear,Reset,Circle,Rectangle,Triangle,Null
 
    }
}
